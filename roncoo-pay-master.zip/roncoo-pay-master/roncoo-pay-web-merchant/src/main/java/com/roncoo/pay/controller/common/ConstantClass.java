package com.roncoo.pay.controller.common;

public class ConstantClass {
    public static final String USER = "rpUserInfo";
}
